"use client"

import { useState } from "react"
import type { Block } from "@/lib/notion-data"

function TodoBlock({ block }: { block: Block }) {
  const [checked, setChecked] = useState(!!block.checked)
  return (
    <div className="flex items-start gap-2 py-[3px]">
      <button
        role="checkbox"
        aria-checked={checked}
        aria-label={block.content}
        onClick={() => setChecked((c) => !c)}
        className="mt-[3px] flex h-[16px] w-[16px] shrink-0 items-center justify-center rounded-[3px] border transition-colors"
        style={{
          backgroundColor: checked ? "var(--notion-blue)" : "transparent",
          borderColor: checked ? "var(--notion-blue)" : "rgba(55,53,47,0.35)",
        }}
      >
        {checked && (
          <svg viewBox="0 0 14 14" className="h-[11px] w-[11px]" fill="none" stroke="white" strokeWidth="2">
            <path d="M2 7l3.5 3.5L12 3.5" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        )}
      </button>
      <span
        className="text-[16px] leading-[1.5]"
        style={{
          textDecoration: checked ? "line-through" : "none",
          color: checked ? "var(--notion-text-muted)" : "var(--notion-text)",
        }}
      >
        {block.content}
      </span>
    </div>
  )
}

export function BlockView({ block, index }: { block: Block; index: number }) {
  switch (block.type) {
    case "heading1":
      return (
        <h1 className="mb-[1px] mt-[26px] text-[30px] font-bold leading-[1.3]">{block.content}</h1>
      )
    case "heading2":
      return (
        <h2 className="mb-[1px] mt-[20px] text-[24px] font-semibold leading-[1.3]">{block.content}</h2>
      )
    case "heading3":
      return (
        <h3 className="mb-[1px] mt-[16px] text-[20px] font-semibold leading-[1.3]">{block.content}</h3>
      )
    case "text":
      return <p className="py-[3px] text-[16px] leading-[1.6]">{block.content}</p>
    case "bulleted":
      return (
        <div className="flex items-start gap-2 py-[3px]">
          <span className="mt-[9px] h-[6px] w-[6px] shrink-0 rounded-full bg-[var(--notion-text)]" />
          <span className="text-[16px] leading-[1.5]">{block.content}</span>
        </div>
      )
    case "numbered":
      return (
        <div className="flex items-start gap-2 py-[3px]">
          <span className="min-w-[18px] text-[16px] leading-[1.5]">{(index ?? 0) + 1}.</span>
          <span className="text-[16px] leading-[1.5]">{block.content}</span>
        </div>
      )
    case "todo":
      return <TodoBlock block={block} />
    case "quote":
      return (
        <blockquote className="my-[6px] border-l-[3px] border-[var(--notion-text)] py-[2px] pl-[14px] text-[16px] leading-[1.5]">
          {block.content}
        </blockquote>
      )
    case "callout":
      return (
        <div
          className="my-[6px] flex items-start gap-3 rounded-[6px] px-4 py-3"
          style={{ backgroundColor: "rgba(55,53,47,0.045)" }}
        >
          <span className="text-[18px] leading-[1.5]">{block.icon}</span>
          <span className="text-[16px] leading-[1.5]">{block.content}</span>
        </div>
      )
    case "divider":
      return <hr className="my-[10px] border-0 border-t" style={{ borderColor: "var(--notion-border)" }} />
    default:
      return null
  }
}
