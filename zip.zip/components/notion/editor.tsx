"use client"

import { useMemo } from "react"
import Image from "next/image"
import {
  Star,
  MessageSquare,
  MoreHorizontal,
  ChevronsRight,
  Smile,
  ImageIcon,
  MessageCircle,
} from "lucide-react"
import type { NotionPage } from "@/lib/notion-data"
import { BlockView } from "./blocks"

interface EditorProps {
  page: NotionPage
  collapsed: boolean
  onExpand: () => void
  breadcrumb: string[]
}

export function Editor({ page, collapsed, onExpand, breadcrumb }: EditorProps) {
  // running index for numbered lists
  const numberedIndices = useMemo(() => {
    const map = new Map<string, number>()
    let n = 0
    for (const b of page.blocks) {
      if (b.type === "numbered") {
        map.set(b.id, n)
        n++
      } else {
        n = 0
      }
    }
    return map
  }, [page])

  return (
    <div className="flex h-full min-w-0 flex-1 flex-col bg-white">
      {/* Top bar */}
      <header className="flex h-[45px] shrink-0 items-center px-3">
        <div className="flex min-w-0 flex-1 items-center gap-1">
          {collapsed && (
            <button
              aria-label="사이드바 열기"
              onClick={onExpand}
              className="flex h-[26px] w-[26px] items-center justify-center rounded-[5px] transition-colors hover:bg-[var(--notion-sidebar-hover)]"
              style={{ color: "var(--notion-text-muted)" }}
            >
              <ChevronsRight className="h-[18px] w-[18px]" />
            </button>
          )}
          <nav className="flex min-w-0 items-center gap-1 text-[14px]">
            {breadcrumb.map((crumb, i) => (
              <span key={i} className="flex items-center gap-1">
                {i > 0 && (
                  <span style={{ color: "var(--notion-text-faint)" }}>/</span>
                )}
                <span
                  className="truncate rounded-[4px] px-1.5 py-0.5 transition-colors hover:bg-[var(--notion-sidebar-hover)]"
                  style={{ color: "var(--notion-text)" }}
                >
                  {crumb}
                </span>
              </span>
            ))}
          </nav>
        </div>

        <div className="flex items-center gap-1 text-[14px]" style={{ color: "var(--notion-text-muted)" }}>
          <button className="hidden rounded-[5px] px-2 py-1 transition-colors hover:bg-[var(--notion-sidebar-hover)] sm:block">
            공유
          </button>
          <button aria-label="댓글" className="flex h-[28px] w-[28px] items-center justify-center rounded-[5px] transition-colors hover:bg-[var(--notion-sidebar-hover)]">
            <MessageSquare className="h-[18px] w-[18px]" />
          </button>
          <button aria-label="즐겨찾기" className="flex h-[28px] w-[28px] items-center justify-center rounded-[5px] transition-colors hover:bg-[var(--notion-sidebar-hover)]">
            <Star className="h-[18px] w-[18px]" />
          </button>
          <button aria-label="더보기" className="flex h-[28px] w-[28px] items-center justify-center rounded-[5px] transition-colors hover:bg-[var(--notion-sidebar-hover)]">
            <MoreHorizontal className="h-[18px] w-[18px]" />
          </button>
        </div>
      </header>

      {/* Scrollable content */}
      <div className="notion-scroll flex-1 overflow-y-auto">
        {/* Cover */}
        {page.cover && (
          <div className="relative h-[180px] w-full sm:h-[220px]">
            <Image
              src={page.cover || "/placeholder.svg"}
              alt=""
              fill
              priority
              className="object-cover"
            />
          </div>
        )}

        <div className="mx-auto w-full max-w-[720px] px-[54px] max-[600px]:px-6">
          {/* Icon */}
          <div className={page.cover ? "relative -mt-[36px]" : "pt-[80px]"}>
            <div className="flex h-[72px] w-[72px] items-center justify-center text-[64px] leading-none">
              {page.icon}
            </div>
          </div>

          {/* Title + hover controls */}
          <div className="group pb-2">
            <div className="mb-2 flex items-center gap-2 opacity-0 transition-opacity group-hover:opacity-100">
              <button className="flex items-center gap-1.5 rounded-[4px] px-1.5 py-1 text-[14px] transition-colors hover:bg-[var(--notion-sidebar-hover)]" style={{ color: "var(--notion-text-muted)" }}>
                <Smile className="h-4 w-4" /> 아이콘 변경
              </button>
              <button className="flex items-center gap-1.5 rounded-[4px] px-1.5 py-1 text-[14px] transition-colors hover:bg-[var(--notion-sidebar-hover)]" style={{ color: "var(--notion-text-muted)" }}>
                <ImageIcon className="h-4 w-4" /> 커버 추가
              </button>
              <button className="flex items-center gap-1.5 rounded-[4px] px-1.5 py-1 text-[14px] transition-colors hover:bg-[var(--notion-sidebar-hover)]" style={{ color: "var(--notion-text-muted)" }}>
                <MessageCircle className="h-4 w-4" /> 댓글 추가
              </button>
            </div>
            <h1 className="text-[40px] font-bold leading-[1.2]">{page.title}</h1>
          </div>

          {/* Blocks */}
          <div className="pb-40">
            {page.blocks.map((block) => (
              <BlockView key={block.id} block={block} index={numberedIndices.get(block.id) ?? 0} />
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
