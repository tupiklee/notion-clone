"use client"

import { useState } from "react"
import { Sidebar } from "@/components/notion/sidebar"
import { Editor } from "@/components/notion/editor"
import { pages } from "@/lib/notion-data"

const breadcrumbs: Record<string, string[]> = {
  "getting-started": ["시작하기"],
  roadmap: ["제품 로드맵"],
  meetings: ["시작하기", "회의록"],
  wiki: ["시작하기", "팀 위키"],
  reading: ["읽을거리"],
  journal: ["일기"],
}

export default function Page() {
  const [activePage, setActivePage] = useState("getting-started")
  const [collapsed, setCollapsed] = useState(false)

  const page = pages[activePage] ?? pages["getting-started"]

  return (
    <main className="notion-app flex h-screen w-full overflow-hidden bg-white">
      {!collapsed && (
        <Sidebar
          activePage={activePage}
          onSelect={setActivePage}
          onCollapse={() => setCollapsed(true)}
        />
      )}
      <Editor
        page={page}
        collapsed={collapsed}
        onExpand={() => setCollapsed(false)}
        breadcrumb={breadcrumbs[activePage] ?? [page.title]}
      />
    </main>
  )
}
