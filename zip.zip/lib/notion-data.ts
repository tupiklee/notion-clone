export type BlockType =
  | "heading1"
  | "heading2"
  | "heading3"
  | "text"
  | "bulleted"
  | "numbered"
  | "todo"
  | "quote"
  | "callout"
  | "divider"

export interface Block {
  id: string
  type: BlockType
  content?: string
  checked?: boolean
  icon?: string
}

export interface NotionPage {
  id: string
  icon: string
  title: string
  cover?: string
  children?: string[]
  blocks: Block[]
}

export interface SidebarItem {
  id: string
  icon: string
  label: string
  children?: SidebarItem[]
}

let counter = 0
const uid = () => `b${counter++}`

export const pages: Record<string, NotionPage> = {
  "getting-started": {
    id: "getting-started",
    icon: "👋",
    title: "시작하기",
    cover: "/notion-cover-gradient.png",
    blocks: [
      {
        id: uid(),
        type: "callout",
        icon: "💡",
        content:
          "이 페이지는 노션 워크스페이스의 예시입니다. 왼쪽 사이드바에서 다른 페이지로 이동해 보세요.",
      },
      { id: uid(), type: "heading1", content: "환영합니다" },
      {
        id: uid(),
        type: "text",
        content:
          "노션은 메모, 문서, 위키, 프로젝트를 한곳에서 관리할 수 있는 올인원 워크스페이스입니다. 아래는 자주 사용하는 블록의 예시입니다.",
      },
      { id: uid(), type: "heading2", content: "오늘 할 일" },
      { id: uid(), type: "todo", content: "팀 회의 안건 정리하기", checked: true },
      { id: uid(), type: "todo", content: "디자인 시안 검토", checked: false },
      { id: uid(), type: "todo", content: "주간 리포트 작성", checked: false },
      { id: uid(), type: "heading2", content: "빠른 링크" },
      { id: uid(), type: "bulleted", content: "제품 로드맵" },
      { id: uid(), type: "bulleted", content: "회의록 모음" },
      { id: uid(), type: "bulleted", content: "팀 위키" },
      { id: uid(), type: "divider" },
      {
        id: uid(),
        type: "quote",
        content: "잘 정리된 워크스페이스는 생각을 정리하는 첫걸음입니다.",
      },
    ],
  },
  roadmap: {
    id: "roadmap",
    icon: "🗺️",
    title: "제품 로드맵",
    blocks: [
      { id: uid(), type: "heading1", content: "2026 제품 로드맵" },
      {
        id: uid(),
        type: "text",
        content:
          "분기별 핵심 목표와 진행 상황을 한눈에 확인합니다. 각 항목을 클릭하면 세부 페이지로 이동합니다.",
      },
      { id: uid(), type: "heading2", content: "1분기" },
      { id: uid(), type: "todo", content: "새 온보딩 플로우 출시", checked: true },
      { id: uid(), type: "todo", content: "모바일 앱 성능 개선", checked: true },
      { id: uid(), type: "heading2", content: "2분기" },
      { id: uid(), type: "todo", content: "실시간 협업 기능", checked: false },
      { id: uid(), type: "todo", content: "AI 요약 베타", checked: false },
      { id: uid(), type: "numbered", content: "요구사항 정의" },
      { id: uid(), type: "numbered", content: "프로토타입 제작" },
      { id: uid(), type: "numbered", content: "사용자 테스트" },
    ],
  },
  meetings: {
    id: "meetings",
    icon: "🗓️",
    title: "회의록",
    blocks: [
      { id: uid(), type: "heading1", content: "주간 팀 회의" },
      {
        id: uid(),
        type: "callout",
        icon: "📌",
        content: "2026년 9월 17일 · 참석자: 지민, 서연, 도현",
      },
      { id: uid(), type: "heading2", content: "안건" },
      { id: uid(), type: "bulleted", content: "지난주 회고" },
      { id: uid(), type: "bulleted", content: "이번 주 우선순위" },
      { id: uid(), type: "bulleted", content: "블로커 공유" },
      { id: uid(), type: "heading2", content: "결정 사항" },
      { id: uid(), type: "text", content: "다음 릴리스 날짜를 10월 첫째 주로 확정했습니다." },
    ],
  },
  wiki: {
    id: "wiki",
    icon: "📚",
    title: "팀 위키",
    blocks: [
      { id: uid(), type: "heading1", content: "팀 위키" },
      {
        id: uid(),
        type: "text",
        content: "팀의 프로세스, 문서, 온보딩 자료를 모아둔 공간입니다.",
      },
      { id: uid(), type: "heading3", content: "온보딩" },
      { id: uid(), type: "bulleted", content: "첫날 체크리스트" },
      { id: uid(), type: "bulleted", content: "개발 환경 설정" },
      { id: uid(), type: "heading3", content: "프로세스" },
      { id: uid(), type: "bulleted", content: "코드 리뷰 가이드" },
      { id: uid(), type: "bulleted", content: "배포 절차" },
    ],
  },
  reading: {
    id: "reading",
    icon: "📖",
    title: "읽을거리",
    blocks: [
      { id: uid(), type: "heading1", content: "읽을거리 리스트" },
      { id: uid(), type: "todo", content: "생산성에 관한 아티클", checked: false },
      { id: uid(), type: "todo", content: "디자인 시스템 사례 연구", checked: true },
      { id: uid(), type: "todo", content: "원격 근무 문화", checked: false },
    ],
  },
  journal: {
    id: "journal",
    icon: "✍️",
    title: "일기",
    blocks: [
      { id: uid(), type: "heading1", content: "오늘의 기록" },
      {
        id: uid(),
        type: "quote",
        content: "매일 조금씩 쓰는 것이 가장 강력한 습관이다.",
      },
      { id: uid(), type: "text", content: "오늘은 새 프로젝트를 시작했다..." },
    ],
  },
}

export const favorites: SidebarItem[] = [
  { id: "getting-started", icon: "👋", label: "시작하기" },
  { id: "roadmap", icon: "🗺️", label: "제품 로드맵" },
]

export const workspacePages: SidebarItem[] = [
  {
    id: "getting-started",
    icon: "👋",
    label: "시작하기",
    children: [
      { id: "meetings", icon: "🗓️", label: "회의록" },
      { id: "wiki", icon: "📚", label: "팀 위키" },
    ],
  },
  {
    id: "roadmap",
    icon: "🗺️",
    label: "제품 로드맵",
  },
]

export const privatePages: SidebarItem[] = [
  { id: "reading", icon: "📖", label: "읽을거리" },
  { id: "journal", icon: "✍️", label: "일기" },
]
